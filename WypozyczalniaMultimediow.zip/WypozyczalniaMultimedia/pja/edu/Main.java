package pja.edu;

import pja.edu.model.*;
import pja.edu.storage.ObjectManager;

public class Main {
    static final String PLIK = "dane.bin";

    public static void main(String[] args) throws Exception {
        ObjectPlus.clearAllExtents();
        DataInitializer.inicjalizuj();
        System.out.println("Po inicjalizacji:");
        podsumowanie();

        ObjectManager.zapiszDoPliku(PLIK);
        System.out.println("Zapisano do " + PLIK);

        ObjectPlus.clearAllExtents();
        System.out.println("Po wyczyszczeniu ekstensji Osoba: " + ObjectPlus.getExtentSize(Osoba.class));

        ObjectManager.wczytajZPliku(PLIK);
        System.out.println("Po wczytaniu:");
        podsumowanie();

        for(Osoba o : ObjectPlus.getExtent(Osoba.class)) {
            try {
                Czytelnik c = o.asCzytelnik();
                System.out.println("Czytelnik " + c + " wypozyczenia: " + c.getWypozyczenia());
            } catch(IllegalStateException ignore) {}
        }

        for(Pozycja p : ObjectPlus.getExtent(Ksiazka.class)) System.out.println("Ksiazka okres=" + p.okresWypozyczenia() + " oplata(10dni)=" + p.oplataZaZwloke(10));
        for(Pozycja p : ObjectPlus.getExtent(Audiobook.class)) System.out.println("Audiobook okres=" + p.okresWypozyczenia() + " oplata(10dni)=" + p.oplataZaZwloke(10));

        for(AudiobookCyfrowy ac : ObjectPlus.getExtent(AudiobookCyfrowy.class)) System.out.println("AudiobookCyfrowy format=" + ac.getFormat() + " rozmiar=" + ac.getRozmiarMB());

        System.out.println("Aktywnych wypozyczen (metoda klasowa): " + Wypozyczenie.liczbaAktywnych());

        for(Wypozyczenie w : ObjectPlus.getExtent(Wypozyczenie.class)) {
            System.out.println("Wypozyczenie przed: " + w + " kara=" + w.getKara());
            w.zwroc();
            System.out.println("Wypozyczenie po zwrocie: " + w + " kara=" + w.getKara());
        }

        for(Oddzial od : ObjectPlus.getExtent(Oddzial.class)) System.out.println("Oddzial " + od + " znajdz KS-014 -> " + od.znajdzEgzemplarz("KS-014"));

        int przed = ObjectPlus.getExtentSize(Recenzja.class);
        for(Recenzja r : ObjectPlus.getExtent(Recenzja.class)) r.delete();
        System.out.println("Recenzje przed usunieciem=" + przed + " po=" + ObjectPlus.getExtentSize(Recenzja.class));

        Oddzial centralny = ObjectPlus.getExtent(Oddzial.class).get(0);
        for(Ksiazka k : ObjectPlus.getExtent(Ksiazka.class)) k.usun();
        System.out.println("Po usunieciu ksiazek: egzemplarzy=" + ObjectPlus.getExtentSize(Egzemplarz.class)
            + " wypozyczen=" + ObjectPlus.getExtentSize(Wypozyczenie.class)
            + " KS-014 w oddziale=" + centralny.znajdzEgzemplarz("KS-014"));
    }

    static void podsumowanie() {
        System.out.println("  Osoba=" + ObjectPlus.getExtentSize(Osoba.class)
            + " Czytelnik=" + ObjectPlus.getExtentSize(Czytelnik.class)
            + " Pracownik=" + ObjectPlus.getExtentSize(Pracownik.class)
            + " Ksiazka=" + ObjectPlus.getExtentSize(Ksiazka.class)
            + " Audiobook=" + ObjectPlus.getExtentSize(Audiobook.class)
            + " AudiobookCyfrowy=" + ObjectPlus.getExtentSize(AudiobookCyfrowy.class)
            + " Egzemplarz=" + ObjectPlus.getExtentSize(Egzemplarz.class)
            + " Oddzial=" + ObjectPlus.getExtentSize(Oddzial.class)
            + " Wypozyczenie=" + ObjectPlus.getExtentSize(Wypozyczenie.class)
            + " Recenzja=" + ObjectPlus.getExtentSize(Recenzja.class));
    }
}

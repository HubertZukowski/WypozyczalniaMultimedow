package pja.edu.gui;

import pja.edu.DataInitializer;
import pja.edu.storage.ObjectManager;

import javax.swing.*;

public class App {
    static final String PLIK = "dane.bin";

    public static void main(String[] args) {
        try {
            boolean wczytano = ObjectManager.wczytajZPliku(PLIK);
            if (!wczytano) {
                DataInitializer.inicjalizuj();
                ObjectManager.zapiszDoPliku(PLIK);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,
                    "Nie udalo sie wczytac danych (" + ex.getMessage() + "). Laduje dane przykladowe.");
            DataInitializer.inicjalizuj();
        }

        WypozyczalniaController ctrl = new WypozyczalniaController(PLIK);
        SwingUtilities.invokeLater(() -> new GlowneOkno(ctrl).setVisible(true));
    }
}

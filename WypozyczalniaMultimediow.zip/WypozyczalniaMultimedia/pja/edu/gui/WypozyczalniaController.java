package pja.edu.gui;

import pja.edu.ObjectPlus;
import pja.edu.model.*;
import pja.edu.storage.ObjectManager;

import java.util.ArrayList;
import java.util.List;

public class WypozyczalniaController {
    private final String plik;

    public WypozyczalniaController(String plik) {
        this.plik = plik;
    }

    public List<Czytelnik> getCzytelnicy() {
        return ObjectPlus.getExtent(Czytelnik.class);
    }

    public List<Wypozyczenie> getWypozyczenia(Czytelnik czytelnik) {
        return new ArrayList<>(czytelnik.getWypozyczenia());
    }

    public List<Egzemplarz> getDostepneEgzemplarze() {
        List<Egzemplarz> dostepne = new ArrayList<>();
        for (Egzemplarz e : ObjectPlus.getExtent(Egzemplarz.class)) {
            if (e.getStan() == StanEgzemplarza.DOSTEPNY) {
                dostepne.add(e);
            }
        }
        return dostepne;
    }

    public Pracownik getObslugujacy() {
        List<Pracownik> pracownicy = ObjectPlus.getExtent(Pracownik.class);
        if (pracownicy.isEmpty()) {
            throw new IllegalStateException("Brak pracownika w systemie");
        }
        return pracownicy.get(0);
    }

    public int getLimit() {
        return Czytelnik.getDomyslnyLimit();
    }

    public Wypozyczenie wypozycz(Czytelnik czytelnik, Egzemplarz egzemplarz) {
        Wypozyczenie w = new Wypozyczenie(czytelnik, getObslugujacy(), egzemplarz);
        zapisz();
        return w;
    }

    public void zwroc(Wypozyczenie wypozyczenie) {
        wypozyczenie.zwroc();
        zapisz();
    }

    public Czytelnik zarejestrujCzytelnika(String imie, String nazwisko, String email,
                                           String ulica, String miasto, String kodPocztowy) {
        Adres adres = new Adres(ulica, miasto, kodPocztowy);
        String numer = nastepnyNumerKarty();
        Osoba osoba = new Osoba(imie, nazwisko, email, adres, numer, null);
        zapisz();
        return osoba.asCzytelnik();
    }

    public String nastepnyNumerKarty() {
        int n = ObjectPlus.getExtentSize(Czytelnik.class) + 1;
        while (true) {
            String kandydat = String.format("K-%03d", n);
            boolean zajety = false;
            for (Czytelnik c : ObjectPlus.getExtent(Czytelnik.class)) {
                if (kandydat.equals(c.getNumerKarty())) { zajety = true; break; }
            }
            if (!zajety) return kandydat;
            n++;
        }
    }

    public List<Pozycja> getPozycje() {
        List<Pozycja> wszystkie = new ArrayList<>();
        wszystkie.addAll(ObjectPlus.getExtent(Ksiazka.class));
        wszystkie.addAll(ObjectPlus.getExtent(Audiobook.class));
        wszystkie.addAll(ObjectPlus.getExtent(AudiobookCyfrowy.class));
        return wszystkie;
    }

    public List<Egzemplarz> getEgzemplarze(Pozycja pozycja) {
        return new ArrayList<>(pozycja.getEgzemplarze());
    }

    public List<Oddzial> getOddzialy() {
        return ObjectPlus.getExtent(Oddzial.class);
    }

    public Ksiazka dodajKsiazke(String tytul, String autor, int rok, int liczbaStron, String isbn, String gatunek) {
        Ksiazka k = new Ksiazka(tytul, autor, rok, liczbaStron, isbn);
        if (gatunek != null && !gatunek.isBlank()) k.dodajGatunek(gatunek);
        zapisz();
        return k;
    }

    public Audiobook dodajAudiobook(String tytul, String autor, int rok, int czas, String lektor, String gatunek) {
        Audiobook a = new Audiobook(tytul, autor, rok, czas, lektor);
        if (gatunek != null && !gatunek.isBlank()) a.dodajGatunek(gatunek);
        zapisz();
        return a;
    }

    public void usunPozycje(Pozycja pozycja) {
        pozycja.usun();
        zapisz();
    }

    public Egzemplarz dodajEgzemplarz(Pozycja pozycja, String sygnatura, Oddzial oddzial) {
        Egzemplarz e = pozycja.dodajEgzemplarz(sygnatura, oddzial);
        zapisz();
        return e;
    }

    public void zapisz() {
        try {
            ObjectManager.zapiszDoPliku(plik);
        } catch (Exception ex) {
            throw new RuntimeException("Blad zapisu danych: " + ex.getMessage(), ex);
        }
    }
}

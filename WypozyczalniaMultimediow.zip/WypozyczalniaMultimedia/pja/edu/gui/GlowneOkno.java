package pja.edu.gui;

import pja.edu.model.Czytelnik;
import pja.edu.model.Egzemplarz;
import pja.edu.model.Wypozyczenie;

import javax.swing.*;
import java.awt.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public class GlowneOkno extends JFrame {
    private final WypozyczalniaController ctrl;

    private final DefaultListModel<Czytelnik> modelCzytelnicy = new DefaultListModel<>();
    private final DefaultListModel<Wypozyczenie> modelWypozyczenia = new DefaultListModel<>();
    private final JList<Czytelnik> listaCzytelnikow = new JList<>(modelCzytelnicy);
    private final JList<Wypozyczenie> listaWypozyczen = new JList<>(modelWypozyczenia);
    private final JComboBox<Egzemplarz> comboEgzemplarze = new JComboBox<>();

    private final JButton btnWypozycz = new JButton("Wypozycz");
    private final JButton btnZwroc = new JButton("Zwroc zaznaczone");
    private final JButton btnRejestracja = new JButton("Rejestracja czytelnika");
    private final JButton btnKatalog = new JButton("Katalog pozycji");
    private final JLabel naglowekWypozyczen = new JLabel("Wypozyczenia");
    private final JLabel stopka = new JLabel();

    public GlowneOkno(WypozyczalniaController ctrl) {
        super("Wypozyczalnia multimediow - Wypozycz egzemplarz");
        this.ctrl = ctrl;
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 580);
        setLocationRelativeTo(null);
        zbudujUI();
        odswiezCzytelnikow();
        odswiezEgzemplarze();
        aktualizujStopke();
    }

    private void zbudujUI() {
        listaCzytelnikow.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listaWypozyczen.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listaWypozyczen.setCellRenderer(new WypozyczenieRenderer());

        JPanel pasek = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        pasek.add(btnRejestracja);
        pasek.add(btnKatalog);

        JPanel lewy = new JPanel(new BorderLayout(0, 4));
        lewy.add(new JLabel("Czytelnicy (ekstensja)"), BorderLayout.NORTH);
        lewy.add(new JScrollPane(listaCzytelnikow), BorderLayout.CENTER);

        JPanel prawy = new JPanel(new BorderLayout(0, 4));
        prawy.add(naglowekWypozyczen, BorderLayout.NORTH);
        prawy.add(new JScrollPane(listaWypozyczen), BorderLayout.CENTER);
        prawy.add(btnZwroc, BorderLayout.SOUTH);

        JPanel srodek = new JPanel(new GridLayout(1, 2, 10, 10));
        srodek.setBorder(BorderFactory.createEmptyBorder(10, 10, 6, 10));
        srodek.add(lewy);
        srodek.add(prawy);

        JPanel formularz = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        formularz.add(new JLabel("Egzemplarz do wypozyczenia (dostepny):"));
        comboEgzemplarze.setPreferredSize(new Dimension(320, 26));
        formularz.add(comboEgzemplarze);
        formularz.add(btnWypozycz);

        stopka.setBorder(BorderFactory.createEmptyBorder(4, 10, 8, 10));

        JPanel dol = new JPanel(new BorderLayout());
        dol.add(formularz, BorderLayout.CENTER);
        dol.add(stopka, BorderLayout.SOUTH);

        setLayout(new BorderLayout());
        add(pasek, BorderLayout.NORTH);
        add(srodek, BorderLayout.CENTER);
        add(dol, BorderLayout.SOUTH);

        listaCzytelnikow.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) pokazWypozyczeniaWybranego();
        });
        btnWypozycz.addActionListener(e -> onWypozycz());
        btnZwroc.addActionListener(e -> onZwroc());
        btnRejestracja.addActionListener(e -> onRejestracja());
        btnKatalog.addActionListener(e -> onKatalog());
    }

    private void odswiezCzytelnikow() {
        Czytelnik zaznaczony = listaCzytelnikow.getSelectedValue();
        modelCzytelnicy.clear();
        for (Czytelnik c : ctrl.getCzytelnicy()) modelCzytelnicy.addElement(c);
        if (zaznaczony != null) listaCzytelnikow.setSelectedValue(zaznaczony, true);
    }

    private void pokazWypozyczeniaWybranego() {
        modelWypozyczenia.clear();
        Czytelnik c = listaCzytelnikow.getSelectedValue();
        if (c == null) {
            naglowekWypozyczen.setText("Wypozyczenia");
            return;
        }
        List<Wypozyczenie> wypozyczenia = ctrl.getWypozyczenia(c);
        naglowekWypozyczen.setText("Wypozyczenia: " + c + " (" + wypozyczenia.size() + ")");
        for (Wypozyczenie w : wypozyczenia) modelWypozyczenia.addElement(w);
    }

    private void odswiezEgzemplarze() {
        comboEgzemplarze.removeAllItems();
        for (Egzemplarz e : ctrl.getDostepneEgzemplarze()) comboEgzemplarze.addItem(e);
    }

    private void aktualizujStopke() {
        String pracownik;
        try {
            pracownik = ctrl.getObslugujacy().toString();
        } catch (RuntimeException ex) {
            pracownik = "(brak)";
        }
        stopka.setText("Pracownik obslugujacy: " + pracownik
                + "   |   limit wypozyczen czytelnika: " + ctrl.getLimit());
    }

    private void onWypozycz() {
        Czytelnik c = listaCzytelnikow.getSelectedValue();
        Egzemplarz e = (Egzemplarz) comboEgzemplarze.getSelectedItem();
        if (c == null) {
            JOptionPane.showMessageDialog(this, "Najpierw wybierz czytelnika z listy.");
            return;
        }
        if (e == null) {
            JOptionPane.showMessageDialog(this, "Brak dostepnego egzemplarza do wypozyczenia.");
            return;
        }
        int okres = e.getPozycja().okresWypozyczenia();
        LocalDate termin = LocalDate.now().plusDays(okres);
        String podsumowanie = "Czytelnik:  " + c + "\n"
                + "Egzemplarz: " + e + "\n"
                + "Okres wypozyczenia: " + okres + " dni\n"
                + "Termin zwrotu: " + termin;
        int wybor = JOptionPane.showConfirmDialog(this, podsumowanie,
                "Podsumowanie wypozyczenia", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (wybor != JOptionPane.OK_OPTION) {
            return;
        }
        try {
            ctrl.wypozycz(c, e);
            odswiezEgzemplarze();
            pokazWypozyczeniaWybranego();
            JOptionPane.showMessageDialog(this,
                    "Wypozyczono egzemplarz " + e + "\nTermin zwrotu: " + termin,
                    "Potwierdzenie wypozyczenia", JOptionPane.INFORMATION_MESSAGE);
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Nie mozna wypozyczyc", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void onZwroc() {
        Wypozyczenie w = listaWypozyczen.getSelectedValue();
        if (w == null) {
            JOptionPane.showMessageDialog(this, "Zaznacz wypozyczenie do zwrotu.");
            return;
        }
        try {
            ctrl.zwroc(w);
            odswiezEgzemplarze();
            pokazWypozyczeniaWybranego();
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Nie mozna zwrocic", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void onRejestracja() {
        RejestracjaOkno okno = new RejestracjaOkno(this, ctrl);
        okno.setVisible(true);
        if (okno.czyZapisano()) {
            odswiezCzytelnikow();
        }
    }

    private void onKatalog() {
        KatalogOkno okno = new KatalogOkno(this, ctrl);
        okno.setVisible(true);
        if (okno.czyZmieniono()) {
            odswiezEgzemplarze();
            pokazWypozyczeniaWybranego();
        }
    }

    private static class WypozyczenieRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                      boolean isSelected, boolean cellHasFocus) {
            Component comp = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (value instanceof Wypozyczenie) {
                Wypozyczenie w = (Wypozyczenie) value;
                BigDecimal kara = w.getKara();
                String txt = w.toString();
                boolean jestKara = kara.compareTo(BigDecimal.ZERO) > 0;
                if (jestKara) txt = txt + "   [kara " + kara + " zl]";
                setText(txt);
                if (jestKara && !isSelected) setForeground(Color.RED);
            }
            return comp;
        }
    }
}

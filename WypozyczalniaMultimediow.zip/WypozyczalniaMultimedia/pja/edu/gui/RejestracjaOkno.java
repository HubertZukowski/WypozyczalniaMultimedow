package pja.edu.gui;

import pja.edu.model.Czytelnik;

import javax.swing.*;
import java.awt.*;

public class RejestracjaOkno extends JDialog {
    private final WypozyczalniaController ctrl;
    private boolean zapisano = false;

    private final JTextField polImie = new JTextField();
    private final JTextField polNazwisko = new JTextField();
    private final JTextField polEmail = new JTextField();
    private final JTextField polUlica = new JTextField();
    private final JTextField polMiasto = new JTextField();
    private final JTextField polKod = new JTextField();

    public RejestracjaOkno(Window wlasciciel, WypozyczalniaController ctrl) {
        super(wlasciciel, "Rejestracja czytelnika", ModalityType.APPLICATION_MODAL);
        this.ctrl = ctrl;
        zbudujUI();
        setSize(480, 400);
        setLocationRelativeTo(wlasciciel);
    }

    public boolean czyZapisano() { return zapisano; }

    private void zbudujUI() {
        JPanel formularz = new JPanel(new GridLayout(8, 2, 8, 8));
        formularz.setBorder(BorderFactory.createEmptyBorder(14, 14, 8, 14));

        formularz.add(new JLabel("Imie:"));            formularz.add(polImie);
        formularz.add(new JLabel("Nazwisko:"));        formularz.add(polNazwisko);
        formularz.add(new JLabel("E-mail:"));          formularz.add(polEmail);
        formularz.add(new JLabel("Ulica:"));           formularz.add(polUlica);
        formularz.add(new JLabel("Miasto:"));          formularz.add(polMiasto);
        formularz.add(new JLabel("Kod pocztowy:"));    formularz.add(polKod);

        JLabel infoKarta = new JLabel(ctrl.nastepnyNumerKarty() + "  (nadawany automatycznie)");
        infoKarta.setForeground(new Color(100, 100, 100));
        formularz.add(new JLabel("Numer karty:"));     formularz.add(infoKarta);

        JLabel infoData = new JLabel("dzis  (nadawana automatycznie)");
        infoData.setForeground(new Color(100, 100, 100));
        formularz.add(new JLabel("Data zapisu:"));     formularz.add(infoData);

        JButton btnZapisz = new JButton("Zapisz");
        JButton btnAnuluj = new JButton("Anuluj");
        JPanel przyciski = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        przyciski.add(btnZapisz);
        przyciski.add(btnAnuluj);

        JLabel nota = new JLabel("Adres (ulica, miasto, kod) zapisywany jest jako jeden obiekt.");
        nota.setForeground(new Color(120, 120, 120));
        nota.setBorder(BorderFactory.createEmptyBorder(6, 16, 0, 8));

        setLayout(new BorderLayout());
        add(formularz, BorderLayout.CENTER);
        JPanel dol = new JPanel(new BorderLayout());
        dol.add(nota, BorderLayout.NORTH);
        dol.add(przyciski, BorderLayout.SOUTH);
        add(dol, BorderLayout.SOUTH);

        btnZapisz.addActionListener(e -> onZapisz());
        btnAnuluj.addActionListener(e -> dispose());
    }

    private void onZapisz() {
        try {
            Czytelnik c = ctrl.zarejestrujCzytelnika(
                    polImie.getText().trim(),
                    polNazwisko.getText().trim(),
                    polEmail.getText().trim(),
                    polUlica.getText().trim(),
                    polMiasto.getText().trim(),
                    polKod.getText().trim());
            zapisano = true;
            JOptionPane.showMessageDialog(this, "Zarejestrowano czytelnika: " + c);
            dispose();
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Nie mozna zarejestrowac", JOptionPane.WARNING_MESSAGE);
        }
    }
}

package pja.edu.gui;

import pja.edu.model.*;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class KatalogOkno extends JDialog {
    private final WypozyczalniaController ctrl;
    private boolean cosZmieniono = false;

    private final DefaultListModel<Pozycja> modelPozycje = new DefaultListModel<>();
    private final DefaultListModel<Egzemplarz> modelEgzemplarze = new DefaultListModel<>();
    private final JList<Pozycja> listaPozycji = new JList<>(modelPozycje);
    private final JList<Egzemplarz> listaEgzemplarzy = new JList<>(modelEgzemplarze);
    private final JLabel naglowekEgz = new JLabel("Egzemplarze");

    public KatalogOkno(Window wlasciciel, WypozyczalniaController ctrl) {
        super(wlasciciel, "Katalog pozycji", ModalityType.APPLICATION_MODAL);
        this.ctrl = ctrl;
        zbudujUI();
        setSize(820, 480);
        setLocationRelativeTo(wlasciciel);
        odswiezPozycje();
    }

    public boolean czyZmieniono() { return cosZmieniono; }

    private void zbudujUI() {
        listaPozycji.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listaEgzemplarzy.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JPanel lewy = new JPanel(new BorderLayout(0, 4));
        lewy.add(new JLabel("Pozycje (ekstensja)"), BorderLayout.NORTH);
        lewy.add(new JScrollPane(listaPozycji), BorderLayout.CENTER);

        JButton btnDodajEgz = new JButton("Dodaj egzemplarz");
        JPanel prawy = new JPanel(new BorderLayout(0, 4));
        prawy.add(naglowekEgz, BorderLayout.NORTH);
        prawy.add(new JScrollPane(listaEgzemplarzy), BorderLayout.CENTER);
        prawy.add(btnDodajEgz, BorderLayout.SOUTH);

        JPanel srodek = new JPanel(new GridLayout(1, 2, 10, 10));
        srodek.setBorder(BorderFactory.createEmptyBorder(10, 10, 6, 10));
        srodek.add(lewy);
        srodek.add(prawy);

        JButton btnDodajPoz = new JButton("Dodaj pozycje");
        JButton btnUsunPoz = new JButton("Usun pozycje");
        JLabel nota = new JLabel("Usuniecie pozycji kasuje wszystkie jej egzemplarze (i ich wypozyczenia).");
        nota.setForeground(new Color(120, 120, 120));

        JPanel przyciski = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        przyciski.add(btnDodajPoz);
        przyciski.add(btnUsunPoz);

        JPanel dol = new JPanel(new BorderLayout());
        dol.add(przyciski, BorderLayout.CENTER);
        dol.add(nota, BorderLayout.SOUTH);

        setLayout(new BorderLayout());
        add(srodek, BorderLayout.CENTER);
        add(dol, BorderLayout.SOUTH);

        listaPozycji.addListSelectionListener(e -> { if (!e.getValueIsAdjusting()) pokazEgzemplarze(); });
        btnDodajPoz.addActionListener(e -> onDodajPozycje());
        btnUsunPoz.addActionListener(e -> onUsunPozycje());
        btnDodajEgz.addActionListener(e -> onDodajEgzemplarz());
    }

    private void odswiezPozycje() {
        modelPozycje.clear();
        for (Pozycja p : ctrl.getPozycje()) modelPozycje.addElement(p);
        modelEgzemplarze.clear();
        naglowekEgz.setText("Egzemplarze");
    }

    private void pokazEgzemplarze() {
        modelEgzemplarze.clear();
        Pozycja p = listaPozycji.getSelectedValue();
        if (p == null) { naglowekEgz.setText("Egzemplarze"); return; }
        List<Egzemplarz> egz = ctrl.getEgzemplarze(p);
        naglowekEgz.setText("Egzemplarze: " + p.getTytul() + " (" + egz.size() + ")");
        for (Egzemplarz e : egz) {
            modelEgzemplarze.addElement(e);
        }
    }

    private void onDodajPozycje() {
        String[] typy = { "Ksiazka", "Audiobook" };
        JComboBox<String> comboTyp = new JComboBox<>(typy);
        JTextField polTytul = new JTextField();
        JTextField polAutor = new JTextField();
        JTextField polRok = new JTextField();
        JTextField polGatunek = new JTextField();
        JTextField polA = new JTextField();
        JTextField polB = new JTextField();
        JLabel etA = new JLabel("Liczba stron:");
        JLabel etB = new JLabel("ISBN:");
        comboTyp.addActionListener(e -> {
            boolean ksiazka = comboTyp.getSelectedIndex() == 0;
            etA.setText(ksiazka ? "Liczba stron:" : "Czas (min):");
            etB.setText(ksiazka ? "ISBN:" : "Lektor:");
        });

        JPanel panel = new JPanel(new GridLayout(7, 2, 6, 6));
        panel.add(new JLabel("Typ:"));        panel.add(comboTyp);
        panel.add(new JLabel("Tytul:"));      panel.add(polTytul);
        panel.add(new JLabel("Autor:"));      panel.add(polAutor);
        panel.add(new JLabel("Rok wydania:"));panel.add(polRok);
        panel.add(new JLabel("Gatunek:"));    panel.add(polGatunek);
        panel.add(etA);                       panel.add(polA);
        panel.add(etB);                       panel.add(polB);

        int wynik = JOptionPane.showConfirmDialog(this, panel, "Dodaj pozycje",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (wynik != JOptionPane.OK_OPTION) return;

        try {
            int rok = Integer.parseInt(polRok.getText().trim());
            if (comboTyp.getSelectedIndex() == 0) {
                int strony = Integer.parseInt(polA.getText().trim());
                ctrl.dodajKsiazke(polTytul.getText().trim(), polAutor.getText().trim(), rok,
                        strony, polB.getText().trim(), polGatunek.getText().trim());
            } else {
                int czas = Integer.parseInt(polA.getText().trim());
                ctrl.dodajAudiobook(polTytul.getText().trim(), polAutor.getText().trim(), rok,
                        czas, polB.getText().trim(), polGatunek.getText().trim());
            }
            cosZmieniono = true;
            odswiezPozycje();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Rok i liczba (strony/czas) musza byc liczbami.", "Bledne dane", JOptionPane.WARNING_MESSAGE);
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Nie mozna dodac", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void onUsunPozycje() {
        Pozycja p = listaPozycji.getSelectedValue();
        if (p == null) {
            JOptionPane.showMessageDialog(this, "Zaznacz pozycje do usuniecia.");
            return;
        }
        int potw = JOptionPane.showConfirmDialog(this,
                "Usunac \"" + p.getTytul() + "\" wraz ze wszystkimi egzemplarzami?",
                "Potwierdzenie", JOptionPane.YES_NO_OPTION);
        if (potw != JOptionPane.YES_OPTION) return;
        try {
            ctrl.usunPozycje(p);
            cosZmieniono = true;
            odswiezPozycje();
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Nie mozna usunac", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void onDodajEgzemplarz() {
        Pozycja p = listaPozycji.getSelectedValue();
        if (p == null) {
            JOptionPane.showMessageDialog(this, "Najpierw wybierz pozycje z listy.");
            return;
        }
        List<Oddzial> oddzialy = ctrl.getOddzialy();
        if (oddzialy.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Brak oddzialu w systemie - nie mozna dodac egzemplarza.");
            return;
        }
        JTextField polSygnatura = new JTextField();
        JComboBox<Oddzial> comboOddzial = new JComboBox<>();
        for (Oddzial o : oddzialy) comboOddzial.addItem(o);

        JPanel panel = new JPanel(new GridLayout(2, 2, 6, 6));
        panel.add(new JLabel("Sygnatura:")); panel.add(polSygnatura);
        panel.add(new JLabel("Oddzial:"));   panel.add(comboOddzial);

        int wynik = JOptionPane.showConfirmDialog(this, panel, "Dodaj egzemplarz",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (wynik != JOptionPane.OK_OPTION) return;

        try {
            ctrl.dodajEgzemplarz(p, polSygnatura.getText().trim(), (Oddzial) comboOddzial.getSelectedItem());
            cosZmieniono = true;
            pokazEgzemplarze();
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Nie mozna dodac", JOptionPane.WARNING_MESSAGE);
        }
    }
}

package pja.edu;

import pja.edu.model.*;

public class DataInitializer {
    public static void inicjalizuj() {
        if(ObjectPlus.getExtentSize(Osoba.class) > 0) return;

        Osoba janek = new Osoba("Janek", "Kowalski", "janek@gmail.com", new Adres("ul Polna 5", "Warszawa", "00-001"), "K-001", null);

        Osoba tomek = new Osoba("Tomek", "Nowak", "tomek@gmail.com", new Adres("ul Krotka 1", "Krakow", "30-001"), "K-002", "bibliotekarz");
        janek.setTelefon("600-100-200");

        Oddzial centralny = new Oddzial("Centralny", "Warszawa");

        Ksiazka ksiazka = new Ksiazka("Lalka", "Boleslaw Prus", 1890, 800, "ISBN-001");
        ksiazka.dodajGatunek("powiesc"); ksiazka.dodajGatunek("klasyka");
        Audiobook audiobook = new Audiobook("Wesele", "Stanislaw Wyspianski", 1901, 180, "Marek Lektor");
        audiobook.dodajGatunek("dramat");
        AudiobookCyfrowy cyfrowy = new AudiobookCyfrowy("Pan Tadeusz", "Adam Mickiewicz", 1834, 600, "Kasia Lektor", 350, "mp3", "plik://pan-tadeusz");
        cyfrowy.dodajGatunek("epopeja"); cyfrowy.dodajGatunek("klasyka");

        Egzemplarz egzKsiazki = ksiazka.dodajEgzemplarz("KS-014", centralny);
        ksiazka.dodajEgzemplarz("KS-015", centralny);
        audiobook.dodajEgzemplarz("AB-007", centralny);
        cyfrowy.dodajEgzemplarz("AC-001", centralny);

        new Wypozyczenie(janek.asCzytelnik(), tomek.asPracownik(), egzKsiazki);
        new Recenzja(janek.asCzytelnik(), audiobook, 5, "Swietny audiobook");
    }
}

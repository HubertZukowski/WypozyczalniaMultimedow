package pja.edu;

import java.io.*;
import java.util.*;

public abstract class ObjectPlus implements Serializable {
    private static final long serialVersionUID = 1L;
    private static Map<Class<? extends ObjectPlus>, List<ObjectPlus>> allExtents = new HashMap<>();

    public ObjectPlus() {
        allExtents.computeIfAbsent(this.getClass(), k -> new ArrayList<>()).add(this);
    }

    protected void removeFromExtent() {
        List<ObjectPlus> e = allExtents.get(this.getClass());
        if(e != null) e.remove(this);
    }

    @SuppressWarnings("unchecked")
    public static <T extends ObjectPlus> List<T> getExtent(Class<T> type) {
        List<ObjectPlus> e = allExtents.get(type);
        return e == null ? new ArrayList<>() : (List<T>)(List<?>) new ArrayList<>(e);
    }

    public static int getExtentSize(Class<? extends ObjectPlus> type) {
        List<ObjectPlus> e = allExtents.get(type);
        return e == null ? 0 : e.size();
    }

    public static void clearAllExtents() { allExtents = new HashMap<>(); }

    public static void writeExtents(ObjectOutputStream s) throws IOException { s.writeObject(allExtents); }

    @SuppressWarnings("unchecked")
    public static void readExtents(ObjectInputStream s) throws IOException, ClassNotFoundException {
        allExtents = (HashMap<Class<? extends ObjectPlus>, List<ObjectPlus>>) s.readObject();
    }
}

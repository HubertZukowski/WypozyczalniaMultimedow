package pja.edu.model;

import java.math.BigDecimal;

public class Audiobook extends Pozycja {
    private static final long serialVersionUID = 1L;
    private int czasTrwania;
    private String lektor;

    public Audiobook(String tytul, String autor, int rokWydania, int czasTrwania, String lektor) {
        super(tytul, autor, rokWydania);
        try {
            setCzasTrwania(czasTrwania);
            setLektor(lektor);
        } catch(RuntimeException e) { usun(); throw e; }
    }

    public void setCzasTrwania(int c) { if(c <= 0) throw new IllegalArgumentException("czas > 0"); this.czasTrwania = c; }
    public void setLektor(String l) { if(l == null || l.isBlank()) throw new IllegalArgumentException("lektor wymagany"); this.lektor = l; }

    @Override public int okresWypozyczenia() { return 14; }
    @Override public BigDecimal oplataZaZwloke(int dni) { int platne = Math.max(0, dni - 2); return BigDecimal.valueOf(platne).multiply(new BigDecimal("0.30")); }
    public int getCzasTrwania() { return czasTrwania; }
    public String getLektor() { return lektor; }
}

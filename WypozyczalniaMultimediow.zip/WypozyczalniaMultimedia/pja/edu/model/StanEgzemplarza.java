package pja.edu.model;

public enum StanEgzemplarza { DOSTEPNY, WYPOZYCZONY }

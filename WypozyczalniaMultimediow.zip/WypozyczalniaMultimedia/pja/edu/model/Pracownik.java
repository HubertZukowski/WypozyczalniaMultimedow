package pja.edu.model;

import pja.edu.ObjectPlus;
import java.time.LocalDate;
import java.util.*;

public class Pracownik extends ObjectPlus {
    private static final long serialVersionUID = 1L;
    private final Osoba wlasciciel;
    private String stanowisko;
    private LocalDate dataZatrudnienia;
    private List<Wypozyczenie> obsluzone = new ArrayList<>();

    Pracownik(Osoba wlasciciel, String stanowisko) {
        super();
        try {
            if(wlasciciel == null) throw new IllegalArgumentException("wlasciciel wymagany");
            this.wlasciciel = wlasciciel;
            setStanowisko(stanowisko);
            this.dataZatrudnienia = LocalDate.now();
        } catch(RuntimeException e) { removeFromExtent(); throw e; }
    }

    public void setStanowisko(String s) { if(s == null || s.isBlank()) throw new IllegalArgumentException("stanowisko wymagane"); this.stanowisko = s; }
    public String getStanowisko() { return stanowisko; }
    public Osoba getWlasciciel() { return wlasciciel; }
    void dodajObsluzoneInternal(Wypozyczenie w) { if(!obsluzone.contains(w)) obsluzone.add(w); }
    void usunObsluzoneInternal(Wypozyczenie w) { obsluzone.remove(w); }
    void usunZEkstensjiInternal() { removeFromExtent(); }
    public List<Wypozyczenie> getObsluzone() { return Collections.unmodifiableList(obsluzone); }

    @Override public String toString() { return wlasciciel.getPelnaNazwa() + " - " + stanowisko; }
}

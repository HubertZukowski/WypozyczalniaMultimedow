package pja.edu.model;

import pja.edu.ObjectPlus;
import java.time.LocalDate;

public class Recenzja extends ObjectPlus {
    private static final long serialVersionUID = 1L;
    private int ocena;
    private String tresc;
    private LocalDate data;
    private final Czytelnik czytelnik;
    private final Pozycja pozycja;
    private boolean usunieta;

    public Recenzja(Czytelnik czytelnik, Pozycja pozycja, int ocena, String tresc) {
        super();
        try {
            if(czytelnik == null || pozycja == null) throw new IllegalArgumentException("czytelnik i pozycja wymagani");
            for(Recenzja r : getExtent(Recenzja.class))
                if(r != this && r.czytelnik == czytelnik && r.pozycja == pozycja) throw new IllegalArgumentException("recenzja tej pozycji juz istnieje");
            setOcena(ocena);
            setTresc(tresc);
            this.data = LocalDate.now();
            this.czytelnik = czytelnik;
            this.pozycja = pozycja;
            czytelnik.dodajRecenzjeInternal(this);
            pozycja.dodajRecenzjeInternal(this);
        } catch(RuntimeException e) { removeFromExtent(); throw e; }
    }

    public void setOcena(int o) { if(usunieta) throw new IllegalStateException("recenzja usunieta"); if(o < 1 || o > 5) throw new IllegalArgumentException("ocena 1-5"); this.ocena = o; }
    public void setTresc(String t) { if(usunieta) throw new IllegalStateException("recenzja usunieta"); if(t == null || t.isBlank()) throw new IllegalArgumentException("tresc wymagana"); this.tresc = t; }

    public void delete() {
        if(usunieta) return;
        czytelnik.usunRecenzjeInternal(this);
        pozycja.usunRecenzjeInternal(this);
        usunieta = true;
        removeFromExtent();
    }

    public boolean isUsunieta() { return usunieta; }
    public int getOcena() { return ocena; }
    public Czytelnik getCzytelnik() { return czytelnik; }
    public Pozycja getPozycja() { return pozycja; }
    @Override public String toString() { return ocena + "/5 - " + pozycja.getTytul() + " (" + czytelnik.getWlasciciel().getPelnaNazwa() + ")"; }
}

package pja.edu.model;

import pja.edu.ObjectPlus;
import java.util.*;

public class Oddzial extends ObjectPlus {
    private static final long serialVersionUID = 1L;
    private String nazwa;
    private String miasto;
    private Map<String, Egzemplarz> egzemplarze = new HashMap<>();

    public Oddzial(String nazwa, String miasto) {
        super();
        try {
            setNazwa(nazwa);
            setMiasto(miasto);
        } catch(RuntimeException e) { removeFromExtent(); throw e; }
    }

    public void setNazwa(String n) { if(n == null || n.isBlank()) throw new IllegalArgumentException("nazwa wymagana"); this.nazwa = n; }
    public void setMiasto(String m) { if(m == null || m.isBlank()) throw new IllegalArgumentException("miasto wymagane"); this.miasto = m; }

    void przechowajInternal(Egzemplarz e) {
        if(e.getOddzial() != null) throw new IllegalStateException("egzemplarz juz przypisany do oddzialu");
        if(egzemplarze.containsKey(e.getSygnatura())) throw new IllegalArgumentException("sygnatura zajeta w oddziale");
        egzemplarze.put(e.getSygnatura(), e);
        e.setOddzialInternal(this);
    }

    void usunEgzemplarzInternal(String sygnatura) { egzemplarze.remove(sygnatura); }

    public Egzemplarz znajdzEgzemplarz(String sygnatura) { return egzemplarze.get(sygnatura); }
    public Collection<Egzemplarz> getEgzemplarze() { return Collections.unmodifiableCollection(egzemplarze.values()); }
    public String getNazwa() { return nazwa; }

    @Override public String toString() { return nazwa + " (" + miasto + ")"; }
}

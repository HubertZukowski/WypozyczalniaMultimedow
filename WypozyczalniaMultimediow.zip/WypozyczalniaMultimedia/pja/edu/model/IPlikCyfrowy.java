package pja.edu.model;

public interface IPlikCyfrowy {
    int getRozmiarMB();
    void setRozmiarMB(int rozmiarMB);
    String getFormat();
    void setFormat(String format);
    String getLinkDoPobrania();
    void setLinkDoPobrania(String link);
    void pobierz();
}

package pja.edu.model;

import java.math.BigDecimal;

public class Ksiazka extends Pozycja {
    private static final long serialVersionUID = 1L;
    private int liczbaStron;
    private String isbn;

    public Ksiazka(String tytul, String autor, int rokWydania, int liczbaStron, String isbn) {
        super(tytul, autor, rokWydania);
        try {
            setLiczbaStron(liczbaStron);
            setIsbn(isbn);
        } catch(RuntimeException e) { usun(); throw e; }
    }

    public void setLiczbaStron(int l) { if(l <= 0) throw new IllegalArgumentException("liczba stron > 0"); this.liczbaStron = l; }
    public void setIsbn(String i) {
        if(i == null || i.isBlank()) throw new IllegalArgumentException("isbn wymagany");
        for(Ksiazka k : getExtent(Ksiazka.class)) if(k != this && i.equals(k.isbn)) throw new IllegalArgumentException("isbn zajety");
        this.isbn = i;
    }

    @Override public int okresWypozyczenia() { return 30; }
    @Override public BigDecimal oplataZaZwloke(int dni) { return BigDecimal.valueOf(dni).multiply(new BigDecimal("0.50")); }
    public int getLiczbaStron() { return liczbaStron; }
    public String getIsbn() { return isbn; }
}

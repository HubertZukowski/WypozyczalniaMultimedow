package pja.edu.model;

import pja.edu.ObjectPlus;
import java.math.BigDecimal;
import java.time.Year;
import java.util.*;

public abstract class Pozycja extends ObjectPlus {
    private static final long serialVersionUID = 1L;
    private String tytul;
    private String autor;
    private int rokWydania;
    private List<Egzemplarz> egzemplarze = new ArrayList<>();
    private List<Recenzja> recenzje = new ArrayList<>();
    private List<String> gatunek = new ArrayList<>();

    public Pozycja(String tytul, String autor, int rokWydania) {
        super();
        try {
            setTytul(tytul);
            setAutor(autor);
            setRokWydania(rokWydania);
        } catch(RuntimeException e) { removeFromExtent(); throw e; }
    }

    public void setTytul(String t) { if(t == null || t.isBlank()) throw new IllegalArgumentException("tytul wymagany"); this.tytul = t; }
    public void setAutor(String a) { if(a == null || a.isBlank()) throw new IllegalArgumentException("autor wymagany"); this.autor = a; }
    public void setRokWydania(int r) { if(r < 1400 || r > Year.now().getValue()) throw new IllegalArgumentException("rok niepoprawny"); this.rokWydania = r; }

    public abstract int okresWypozyczenia();
    public abstract BigDecimal oplataZaZwloke(int dni);

    public int getLiczbaEgzemplarzy() { return egzemplarze.size(); }

    public void dodajGatunek(String g) { if(g == null || g.isBlank()) throw new IllegalArgumentException("gatunek wymagany"); gatunek.add(g); }
    public List<String> getGatunki() { return new ArrayList<>(gatunek); }

    public Egzemplarz dodajEgzemplarz(String sygnatura, Oddzial oddzial) {
        if(oddzial == null) throw new IllegalArgumentException("oddzial wymagany");
        Egzemplarz e = new Egzemplarz(this, oddzial, sygnatura);
        egzemplarze.add(e);
        return e;
    }

    public void usun() {
        for(Egzemplarz e : new ArrayList<>(egzemplarze)) e.usunKaskadowo();
        egzemplarze.clear();
        for(Recenzja r : new ArrayList<>(recenzje)) r.delete();
        removeFromExtent();
    }

    public List<Egzemplarz> getEgzemplarze() { return Collections.unmodifiableList(egzemplarze); }

    void dodajRecenzjeInternal(Recenzja r) { if(!recenzje.contains(r)) recenzje.add(r); }
    void usunRecenzjeInternal(Recenzja r) { recenzje.remove(r); }
    public List<Recenzja> getRecenzje() { return Collections.unmodifiableList(recenzje); }

    public String getTytul() { return tytul; }
    public String getAutor() { return autor; }
    public int getRokWydania() { return rokWydania; }

    @Override public String toString() { return tytul + " - " + autor; }
}

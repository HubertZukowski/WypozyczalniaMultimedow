package pja.edu.model;

import pja.edu.ObjectPlus;
import java.math.BigDecimal;
import java.time.LocalDate;

public class Wypozyczenie extends ObjectPlus {
    private static final long serialVersionUID = 1L;
    private LocalDate dataWypozyczenia;
    private Czytelnik czytelnik;
    private Pracownik pracownik;
    private Egzemplarz egzemplarz;
    private Wypozyczone wypozyczone;
    private Zwrocone zwrocone;

    public Wypozyczenie(Czytelnik czytelnik, Pracownik pracownik, Egzemplarz egzemplarz) {
        super();
        try {
            if(czytelnik == null || pracownik == null || egzemplarz == null) throw new IllegalArgumentException("czytelnik, pracownik, egzemplarz wymagani");
            if(egzemplarz.getStan() != StanEgzemplarza.DOSTEPNY) throw new IllegalStateException("egzemplarz niedostepny");
            if(liczbaAktywnych(czytelnik) >= Czytelnik.getDomyslnyLimit()) throw new IllegalStateException("przekroczony limit wypozyczen czytelnika");
            this.dataWypozyczenia = LocalDate.now();
            this.czytelnik = czytelnik;
            this.pracownik = pracownik;
            this.egzemplarz = egzemplarz;
            int okres = egzemplarz.getPozycja().okresWypozyczenia();
            this.wypozyczone = new Wypozyczone(LocalDate.now().plusDays(okres));
            this.zwrocone = null;
            czytelnik.dodajWypozyczenieInternal(this);
            pracownik.dodajObsluzoneInternal(this);
            egzemplarz.dodajWypozyczenieInternal(this);
            egzemplarz.setStanInternal(StanEgzemplarza.WYPOZYCZONY);
        } catch(RuntimeException e) { removeFromExtent(); throw e; }
    }

    public void zwroc() {
        if(zwrocone != null) throw new IllegalStateException("juz zwrocone");
        this.zwrocone = new Zwrocone(LocalDate.now());
        this.wypozyczone = null;
        egzemplarz.setStanInternal(StanEgzemplarza.DOSTEPNY);
    }

    public BigDecimal getKara() {
        if(wypozyczone == null) return BigDecimal.ZERO;
        if(!wypozyczone.przeterminowane()) return BigDecimal.ZERO;
        return egzemplarz.getPozycja().oplataZaZwloke(wypozyczone.dniZwloki());
    }

    public void delete() {
        czytelnik.usunWypozyczenieInternal(this);
        pracownik.usunObsluzoneInternal(this);
        egzemplarz.usunWypozyczenieInternal(this);
        if(wypozyczone != null) egzemplarz.setStanInternal(StanEgzemplarza.DOSTEPNY);
        removeFromExtent();
    }

    public static long liczbaAktywnych() {
        long n = 0;
        for(Wypozyczenie w : getExtent(Wypozyczenie.class)) if(w.czyAktywne()) n++;
        return n;
    }

    private static long liczbaAktywnych(Czytelnik c) {
        long n = 0;
        for(Wypozyczenie w : c.getWypozyczenia()) if(w.czyAktywne()) n++;
        return n;
    }

    public boolean czyAktywne() { return wypozyczone != null; }
    public Czytelnik getCzytelnik() { return czytelnik; }
    public Pracownik getPracownik() { return pracownik; }
    public Egzemplarz getEgzemplarz() { return egzemplarz; }
    public Wypozyczone getWypozyczone() { return wypozyczone; }
    public Zwrocone getZwrocone() { return zwrocone; }

    @Override public String toString() {
        String stanTxt = wypozyczone != null ? wypozyczone.toString() : zwrocone.toString();
        return egzemplarz.getSygnatura() + " -> " + czytelnik.getWlasciciel().getPelnaNazwa() + " (" + stanTxt + ")";
    }
}

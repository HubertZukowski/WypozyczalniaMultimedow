package pja.edu.model;

import pja.edu.ObjectPlus;

public class Osoba extends ObjectPlus {
    private static final long serialVersionUID = 1L;
    private String imie;
    private String nazwisko;
    private String email;
    private String telefon;
    private Adres adres;
    private Czytelnik czytelnik;
    private Pracownik pracownik;

    public Osoba(String imie, String nazwisko, String email, Adres adres, String numerKarty, String stanowisko) {
        super();
        try {
            setImie(imie);
            setNazwisko(nazwisko);
            setEmail(email);
            setAdres(adres);
            boolean chceCzytelnika = numerKarty != null && !numerKarty.isBlank();
            boolean chcePracownika = stanowisko != null && !stanowisko.isBlank();
            if(!chceCzytelnika && !chcePracownika) throw new IllegalArgumentException("osoba musi miec co najmniej jedna role");
            if(chceCzytelnika) this.czytelnik = new Czytelnik(this, numerKarty);
            if(chcePracownika) this.pracownik = new Pracownik(this, stanowisko);
        } catch(RuntimeException e) {
            if(czytelnik != null) czytelnik.usunZEkstensjiInternal();
            if(pracownik != null) pracownik.usunZEkstensjiInternal();
            removeFromExtent();
            throw e;
        }
    }

    public void setImie(String i) { if(i == null || i.isBlank()) throw new IllegalArgumentException("imie wymagane"); this.imie = i; }
    public void setNazwisko(String n) { if(n == null || n.isBlank()) throw new IllegalArgumentException("nazwisko wymagane"); this.nazwisko = n; }
    public void setEmail(String e) {
        if(e == null || e.isBlank()) throw new IllegalArgumentException("email wymagany");
        int at = e.indexOf('@'); if(at <= 0 || at >= e.length() - 1) throw new IllegalArgumentException("email niepoprawny");
        for(Osoba o : getExtent(Osoba.class)) if(o != this && e.equals(o.getEmail())) throw new IllegalArgumentException("email zajety");
        this.email = e;
    }
    public void setAdres(Adres a) { if(a == null) throw new IllegalArgumentException("adres wymagany"); this.adres = a; }

    public Czytelnik asCzytelnik() { if(czytelnik == null) throw new IllegalStateException("osoba nie jest czytelnikiem"); return czytelnik; }
    public Pracownik asPracownik() { if(pracownik == null) throw new IllegalStateException("osoba nie jest pracownikiem"); return pracownik; }
    public boolean czyMaRole() { return czytelnik != null || pracownik != null; }

    public String getPelnaNazwa() { return imie + " " + nazwisko; }
    public void setTelefon(String t) { this.telefon = (t == null || t.isBlank()) ? null : t; }
    public String getTelefon() { return telefon; }
    public String getEmail() { return email; }
    public Adres getAdres() { return adres; }

    @Override public String toString() { return getPelnaNazwa(); }
}

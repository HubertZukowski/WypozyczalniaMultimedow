package pja.edu.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Wypozyczone implements Serializable {
    private static final long serialVersionUID = 1L;
    private final LocalDate terminZwrotu;

    public Wypozyczone(LocalDate terminZwrotu) {
        if(terminZwrotu == null) throw new IllegalArgumentException("termin wymagany");
        this.terminZwrotu = terminZwrotu;
    }

    public LocalDate getTerminZwrotu() { return terminZwrotu; }
    public boolean przeterminowane() { return LocalDate.now().isAfter(terminZwrotu); }
    public int dniZwloki() { return (int) Math.max(0, ChronoUnit.DAYS.between(terminZwrotu, LocalDate.now())); }
    @Override public String toString() { return "wypozyczone, termin " + terminZwrotu; }
}

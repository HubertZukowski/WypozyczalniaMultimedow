package pja.edu.model;

import pja.edu.ObjectPlus;
import java.util.*;

public class Egzemplarz extends ObjectPlus {
    private static final long serialVersionUID = 1L;
    private final Pozycja pozycja;
    private Oddzial oddzial;
    private String sygnatura;
    private StanEgzemplarza stan;
    private List<Wypozyczenie> wypozyczenia = new ArrayList<>();

    Egzemplarz(Pozycja pozycja, Oddzial oddzial, String sygnatura) {
        super();
        try {
            if(pozycja == null) throw new IllegalArgumentException("pozycja wymagana");
            if(oddzial == null) throw new IllegalArgumentException("oddzial wymagany");
            this.pozycja = pozycja;
            setSygnatura(sygnatura);
            this.stan = StanEgzemplarza.DOSTEPNY;
            oddzial.przechowajInternal(this);
        } catch(RuntimeException e) { removeFromExtent(); throw e; }
    }

    private void setSygnatura(String s) { if(s == null || s.isBlank()) throw new IllegalArgumentException("sygnatura wymagana"); this.sygnatura = s; }
    void setOddzialInternal(Oddzial o) { this.oddzial = o; }
    void setStanInternal(StanEgzemplarza s) { this.stan = s; }
    void dodajWypozyczenieInternal(Wypozyczenie w) { if(!wypozyczenia.contains(w)) wypozyczenia.add(w); }
    void usunWypozyczenieInternal(Wypozyczenie w) { wypozyczenia.remove(w); }

    public String getSygnatura() { return sygnatura; }
    public StanEgzemplarza getStan() { return stan; }
    public Pozycja getPozycja() { return pozycja; }
    public Oddzial getOddzial() { return oddzial; }
    public List<Wypozyczenie> getWypozyczenia() { return Collections.unmodifiableList(wypozyczenia); }

    void usunKaskadowo() {
        for(Wypozyczenie w : new ArrayList<>(wypozyczenia)) w.delete();
        if(oddzial != null) oddzial.usunEgzemplarzInternal(sygnatura);
        removeFromExtent();
    }

    @Override public String toString() { return sygnatura + " (" + pozycja.getTytul() + ")"; }
}

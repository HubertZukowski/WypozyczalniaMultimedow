package pja.edu.model;

public class AudiobookCyfrowy extends Audiobook implements IPlikCyfrowy {
    private static final long serialVersionUID = 1L;
    private int rozmiarMB;
    private String format;
    private String linkDoPobrania;

    public AudiobookCyfrowy(String tytul, String autor, int rokWydania, int czasTrwania, String lektor,
                            int rozmiarMB, String format, String linkDoPobrania) {
        super(tytul, autor, rokWydania, czasTrwania, lektor);
        try {
            setRozmiarMB(rozmiarMB);
            setFormat(format);
            setLinkDoPobrania(linkDoPobrania);
        } catch(RuntimeException e) { usun(); throw e; }
    }

    @Override public int getRozmiarMB() { return rozmiarMB; }
    @Override public void setRozmiarMB(int r) { if(r <= 0) throw new IllegalArgumentException("rozmiar > 0"); this.rozmiarMB = r; }
    @Override public String getFormat() { return format; }
    @Override public void setFormat(String f) { if(f == null || f.isBlank()) throw new IllegalArgumentException("format wymagany"); this.format = f; }
    @Override public String getLinkDoPobrania() { return linkDoPobrania; }
    @Override public void setLinkDoPobrania(String l) { if(l == null || l.isBlank()) throw new IllegalArgumentException("link wymagany"); this.linkDoPobrania = l; }
    @Override public void pobierz() {  }
}

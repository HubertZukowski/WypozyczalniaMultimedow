package pja.edu.model;

import pja.edu.ObjectPlus;
import java.time.LocalDate;
import java.util.*;

public class Czytelnik extends ObjectPlus {
    private static final long serialVersionUID = 1L;
    private static int domyslnyLimit = 5;
    private final Osoba wlasciciel;
    private String numerKarty;
    private LocalDate dataZapisu;
    private List<Wypozyczenie> wypozyczenia = new ArrayList<>();
    private List<Recenzja> recenzje = new ArrayList<>();

    Czytelnik(Osoba wlasciciel, String numerKarty) {
        super();
        try {
            if(wlasciciel == null) throw new IllegalArgumentException("wlasciciel wymagany");
            this.wlasciciel = wlasciciel;
            setNumerKarty(numerKarty);
            this.dataZapisu = LocalDate.now();
        } catch(RuntimeException e) { removeFromExtent(); throw e; }
    }

    public void setNumerKarty(String n) {
        if(n == null || n.isBlank()) throw new IllegalArgumentException("numer karty wymagany");
        for(Czytelnik c : getExtent(Czytelnik.class)) if(c != this && n.equals(c.numerKarty)) throw new IllegalArgumentException("numer karty zajety");
        this.numerKarty = n;
    }

    public static int getDomyslnyLimit() { return domyslnyLimit; }
    public String getNumerKarty() { return numerKarty; }
    public Osoba getWlasciciel() { return wlasciciel; }
    public List<Wypozyczenie> getWypozyczenia() { return Collections.unmodifiableList(wypozyczenia); }
    public List<Recenzja> getRecenzje() { return Collections.unmodifiableList(recenzje); }

    void dodajWypozyczenieInternal(Wypozyczenie w) { if(!wypozyczenia.contains(w)) wypozyczenia.add(w); }
    void usunWypozyczenieInternal(Wypozyczenie w) { wypozyczenia.remove(w); }
    void dodajRecenzjeInternal(Recenzja r) { if(!recenzje.contains(r)) recenzje.add(r); }
    void usunRecenzjeInternal(Recenzja r) { recenzje.remove(r); }
    void usunZEkstensjiInternal() { removeFromExtent(); }

    @Override public String toString() { return wlasciciel.getPelnaNazwa() + " (" + numerKarty + ")"; }
}

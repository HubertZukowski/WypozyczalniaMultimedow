package pja.edu.model;

import java.io.Serializable;
import java.util.Objects;

public class Adres implements Serializable {
    private static final long serialVersionUID = 1L;
    private String ulica;
    private String miasto;
    private String kodPocztowy;

    public Adres(String ulica, String miasto, String kodPocztowy) {
        setUlica(ulica);
        setMiasto(miasto);
        setKodPocztowy(kodPocztowy);
    }

    public void setUlica(String u) { if(u == null || u.isBlank()) throw new IllegalArgumentException("ulica wymagana"); this.ulica = u; }
    public void setMiasto(String m) { if(m == null || m.isBlank()) throw new IllegalArgumentException("miasto wymagane"); this.miasto = m; }
    public void setKodPocztowy(String k) { if(k == null || k.isBlank()) throw new IllegalArgumentException("kod wymagany"); this.kodPocztowy = k; }

    public String getUlica() { return ulica; }
    public String getMiasto() { return miasto; }
    public String getKodPocztowy() { return kodPocztowy; }

    @Override public boolean equals(Object o) {
        if(this == o) return true;
        if(!(o instanceof Adres)) return false;
        Adres a = (Adres) o;
        return Objects.equals(ulica, a.ulica) && Objects.equals(miasto, a.miasto) && Objects.equals(kodPocztowy, a.kodPocztowy);
    }
    @Override public int hashCode() { return Objects.hash(ulica, miasto, kodPocztowy); }
    @Override public String toString() { return ulica + ", " + kodPocztowy + " " + miasto; }
}

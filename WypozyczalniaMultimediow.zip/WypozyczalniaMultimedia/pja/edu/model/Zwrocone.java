package pja.edu.model;

import java.io.Serializable;
import java.time.LocalDate;

public class Zwrocone implements Serializable {
    private static final long serialVersionUID = 1L;
    private final LocalDate dataZwrotu;

    public Zwrocone(LocalDate dataZwrotu) {
        if(dataZwrotu == null) throw new IllegalArgumentException("data zwrotu wymagana");
        this.dataZwrotu = dataZwrotu;
    }

    public LocalDate getDataZwrotu() { return dataZwrotu; }
    @Override public String toString() { return "zwrocone " + dataZwrotu; }
}

package pja.edu.storage;

import pja.edu.ObjectPlus;
import java.io.*;

public class ObjectManager {
    public static void zapisz(ObjectOutputStream s) throws IOException { ObjectPlus.writeExtents(s); }
    public static void wczytaj(ObjectInputStream s) throws IOException, ClassNotFoundException { ObjectPlus.readExtents(s); }

    public static void zapiszDoPliku(String sciezka) throws IOException {
        try(ObjectOutputStream s = new ObjectOutputStream(new FileOutputStream(sciezka))) { zapisz(s); }
    }

    public static boolean wczytajZPliku(String sciezka) throws IOException, ClassNotFoundException {
        File f = new File(sciezka);
        if(!f.exists() || f.length() == 0) return false;
        try(ObjectInputStream s = new ObjectInputStream(new FileInputStream(sciezka))) { wczytaj(s); return true; }
    }
}
